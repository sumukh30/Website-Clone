/**
 * @license
 * Copyright (c) 2014, 2022, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/*
 * Your application specific code will go here
 */
define(['knockout', 'ojs/ojcontext', 'ojs/ojmodule-element-utils', 'ojs/ojresponsiveutils', 'ojs/ojresponsiveknockoututils', 'ojs/ojcorerouter', 'ojs/ojmodulerouter-adapter', 'ojs/ojknockoutrouteradapter', 'ojs/ojurlparamadapter', 'ojs/ojarraydataprovider', 'ojs/ojknockouttemplateutils', 'ojs/ojmodule-element', 'ojs/ojknockout'],
  function(ko, Context, moduleUtils, ResponsiveUtils, ResponsiveKnockoutUtils, CoreRouter, ModuleRouterAdapter, KnockoutRouterAdapter, UrlParamAdapter, ArrayDataProvider, KnockoutTemplateUtils) {

     function ControllerViewModel() {

        this.KnockoutTemplateUtils = KnockoutTemplateUtils;

        // Handle announcements sent when pages change, for Accessibility.
        this.manner = ko.observable('polite');
        this.message = ko.observable();

        announcementHandler = (event) => {
          this.message(event.detail.message);
          this.manner(event.detail.manner);
      };

      document.getElementById('globalBody').addEventListener('announce', announcementHandler, false);

      // Media queries for repsonsive layouts
      const smQuery = ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY);
      this.smScreen = ResponsiveKnockoutUtils.createMediaQueryObservable(smQuery);

      let navData = [
        { path: '', redirect: 'dashboard' },
        { path: 'dashboard', detail: { label: 'Home', iconClass: 'oj-ux-ico-home' } },
        { path: 'incidents', detail: { label: 'Projects', iconClass: 'oj-ux-ico-project-alt' } },
        { path: 'customers', detail: { label: 'FAQs', iconClass: 'oj-ux-ico-lightbulb-question' } },
        { path: 'about', detail: { label: 'Contact', iconClass: 'oj-ux-ico-contact-group' } }
      ];
      // Router setup
      let router = new CoreRouter(navData, {
        urlAdapter: new UrlParamAdapter()
      });
	  navigateHandler = (event) => {
         console.log(event);
         router.go({path: 'incidents'});
       };
	  document.addEventListener('navigate', navigateHandler);
	  
	  navigaterHandler = (event) => {
         console.log(event);
         router.go({path: 'customers'});
       };
	  document.addEventListener('navigater', navigaterHandler);
	  
	  navigatedHandler = (event) => {
         console.log(event);
         router.go({path: 'about'});
       };
	  document.addEventListener('navigated', navigatedHandler);
      router.sync();
	  
	  

      this.moduleAdapter = new ModuleRouterAdapter(router);

      this.selection = new KnockoutRouterAdapter(router);

      // Setup the navDataProvider with the routes, excluding the first redirected
      // route.
      this.navDataProvider = new ArrayDataProvider(navData.slice(1), {keyAttributes: "path"});

      // Header
      // Application Name used in Branding Area
      this.appName = ko.observable("");
      // User Info used in Global Navigation area
      

      // Footer
      this.footerLinks = [
        {name: 'FreeCodeCamp', linkId: 'hm', linkTarget:'https://www.freecodecamp.org/?ref=blog.codewell.cc'},
        { name: "HackerRank", id: "pj", linkTarget: 'https://www.hackerrank.com/' },
        { name: "w3schools", id: "faq", linkTarget: 'https://www.w3schools.com/' },
        { name: "TopCoder", id: "cots", linkTarget: 'https://www.topcoder.com/challenges/?pageIndex=1' },
       
      ];
     }

     // release the application bootstrap busy state
     Context.getPageContext().getBusyContext().applicationBootstrapComplete();

     return new ControllerViewModel();
  }
);
