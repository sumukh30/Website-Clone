/**
 * @license
 * Copyright (c) 2014, 2022, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/*
 * Your incidents ViewModel code goes here
 */
define(['../accUtils',"knockout","ojs/ojarraydataprovider", "ojs/ojtranslation","ojs/ojresponsiveknockoututils","ojs/ojcheckboxset", "ojs/ojselectsingle", "ojs/ojdataprovider", "ojs/ojknockout", "ojs/ojlistview", "ojs/ojgauge", "ojs/ojbutton", "ojs/ojlistitemlayout","ojs/ojactioncard"],
 function(accUtils,ko,ArrayDataProvider, Translations,ResponsiveKnockoutUtils) {
    function IncidentsViewModel() {
		var self=this;
      // Below are a set of the ViewModel methods invoked by the oj-module component.
      // Please reference the oj-module jsDoc for additional information.
	  self.employees = [
                  {
                      name: "Abstract",
                      department: "Level 1",
                      title:"This is level 1 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 1,
                  },
                  {
                      name: "Ecwid",
                      department: "Level 2",
                      title:"This is level 2 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 2,
                  },
                  {
                      name: "Canal Street Market",
                      
                      department: "Level 3",
                     title:"This is level 3 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 3,
                  },
                  {
                      name: "Monstercat",
                      
                      department: "Level 2",
                      title:"This is level 2 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 4,
                  },
                  {
                      name: "Instrument",
                      
                      department: "Level 1",
                     title:"This is level 1 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 5,
                  },
                  {
                      name: "Lobe",
                     
                      department: "Level 1",
                      title:"This is level 1 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 6,
                  },
                  {
                      name: "Pulse",
                      
                      department: "Level 1",
                      title:"This is level 1 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 7,
                  },
                  {
                      name: "Qrates",
                     
                      department: "Level 3",
                      title:"This is level 3 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 8,
                  },
                  {
                      name: "Stark",
                      
                      department: "Level 3",
                      title:"This is level 3 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 9,
                  },
                  {
                      name: "Starbucks",
                      
                      department: "Level 2",
                      title:"This is level 2 project",
                      expanded: ko.observable(false),
                      inserted: ko.observable(true),
                      id: 10,
                  },
              ];
              
	  
	  self.widthQuery = ResponsiveKnockoutUtils.createMediaQueryObservable("(min-width: 600px)");
        self.dataprovider = ko.observable();
              self.handleFilterChanged = (event) => {
                  // const values = self.currentDepartment();
                  // const layout = document.getElementById("masonryLayout");
				  console.log(event);
				  //console.log(test);
				  var temparray=[];
				  var values=event.detail.value;
				  if(values.length==0){
					 self.dataprovider(new ArrayDataProvider(temparray)) ;
				  }
					else if(values.length==1){
						temparray = self.employees.filter(function (el) {
				return el.department==event.detail.value[0];
				
			});
						console.log(temparray);
							// if(self.employees.department==event.detail.value[0]){
										// console.log(self.employees.name);
						self.dataprovider(temparray);				
							// }
					}
					else if(values.length==2){
						temparray=self.employees.filter(function (el){
							return el.department==event.detail.value[0] ||
							el.department==event.detail.value[1];
						});
						console.log(temparray);
						self.dataprovider(temparray);
					}
							
					else{
						self.dataprovider(self.employees);
					}
					 
                  // const checked = event.detail.originalEvent.target.checked;
                  // if (checked) {
                      // self.employees.forEach((employee) => {
                          // if (!employee.inserted() && values.includes(employee.department)) {
                              // layout.insertTile(`#tile${employee.id}`, employee.id - 1);
                          // }
                      // });
                  // }
                  // else {
                      // const tiles = self.employees.filter((employee) => !values.includes(employee.department));
                      // tiles.forEach((tile) => layout.removeTile(`#tile${tile.id}`));
                  // }
              };
              self.closestByClass = (el, className) => {
                  while (!el.classList.contains(className)) {
                      el = el.parentNode;
                      if (!el) {
                          return null;
                      }
                  }
                  return el;
              };
              self.demoHandleInsert = (event) => {
                  const tile = event.detail.tile;
                  const context = ko.contextFor(tile);
                  let data = context.$current.data;
                  data.inserted(true);
              };
              self.demoHandleRemove = (event) => {
                  const tile = event.detail.tile;
                  const context = ko.contextFor(tile);
                  let data = context.$current.data;
                  data.inserted(false);
                  let removedTilesHolder = document.getElementById("removedTilesHolder");
                  //removedTilesHolder.appendChild(tile);
              };
              self.resizeTile = (event, current) => {
                  const target = event.target;
                  const tile = self.closestByClass(target, "demo-tile");
                  let masonryLayout = self.closestByClass(tile, "oj-masonrylayout");
                  const data = current.data;
                  masonryLayout.resizeTile("#" + tile.getAttribute("id"), data.expanded()
                      ? "oj-masonrylayout-tile-1x1"
                      : "oj-masonrylayout-tile-2x1");
              };
              // This listener is called before the tile is resized.
              self.handleBeforeResize = (event) => {
                  const tile = event.detail.tile;
                  const context = ko.contextFor(tile);
                  let data = context.$current.data;
                  if (data.expanded()) {
                      data.expanded(false);
                      self.handledCollapse = true;
                  }
              };
              // This listener is called after the tile is resized.
              self.handleResize = (event) => {
                  if (!self.handledCollapse) {
                      const tile = event.detail.tile;
                      const context = ko.contextFor(tile);
                      let data = context.$current.data;
                      if (!data.expanded()) {
                          data.expanded(true);
                      }
                  }
                  self.handledCollapse = false;
              };
              self.getTileId = (index) => {
                  return "tile" + (index + 1);
              };
              self.getLabelId = (index) => {
                  return "label" + (index + 1);
              };
              self.getButtonId = (index) => {
                  return "resizeButton" + (index + 1);
              };
              self.getButtonLabelledBy = (index) => {
                  return self.getButtonId(index) + " " + self.getLabelId(index);
              };
              self.getButtonLabel = (data) => {
                  return data.expanded()
                      ? Translations.getTranslatedString("oj-panel.labelAccButtonCollapse")
                      : Translations.getTranslatedString("oj-panel.labelAccButtonExpand");
              };
              self.getButtonIcon = (data) => {
                  return {
                      "oj-panel-expand-icon": !data.expanded(),
                      "oj-panel-collapse-icon": data.expanded(),
                  };
              };
              self.currentDepartment = ko.observableArray([
                  "Level 1",
                  "Level 2",
                  "Level 3",
              ]);
              self.departmentOptions = [
                  { id: "l1", value: "Level 1", department: "Level 1" },
                  { id: "l2", value: "Level 2", department: "Level 2" },
                  {
                      id: "l3",
                      value: "Level 3",
                      department: "Level 3",
                  },
              ];
              
        self.dataprovider = ko.observable(new ArrayDataProvider(self.employees));
             

      /**
       * Optional ViewModel method invoked after the View is inserted into the
       * document DOM.  The application can put logic that requires the DOM being
       * attached here.
       * This method might be called multiple times - after the View is created
       * and inserted into the DOM and after the View is reconnected
       * after being disconnected.
       */
      this.connected = () => {
        accUtils.announce('Incidents page loaded.');
        document.title = "Incidents";
        // Implement further logic if needed
      };

      /**
       * Optional ViewModel method invoked after the View is disconnected from the DOM.
       */
      this.disconnected = () => {
        // Implement if needed
      };

      /**
       * Optional ViewModel method invoked after transition to the new View is complete.
       * That includes any possible animation between the old and the new View.
       */
      this.transitionCompleted = () => {
        // Implement if needed
      };
    }

    /*
     * Returns an instance of the ViewModel providing one instance of the ViewModel. If needed,
     * return a constructor for the ViewModel so that the ViewModel is constructed
     * each time the view is displayed.
     */
    return IncidentsViewModel;
 }
);
